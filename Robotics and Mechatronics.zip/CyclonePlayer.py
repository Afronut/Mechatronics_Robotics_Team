
from __future__ import print_function
from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import numpy as np
from difflib import SequenceMatcher
import sys
import RPi.GPIO as GPIO



camera = PiCamera()
camera.resolution = (150, 150)
camera.framerate = 30
rawCapture = PiRGBArray(camera, size=(150, 150))
time.sleep(0.1)

def similar(a, b):
	return SequenceMatcher(None, a, b).ratio()

def nothing(*arg):
	pass

def limit(inputVal,limits):
	output=inputVal
	for i,val in enumerate(inputVal,0):
		if val>limits[i][1]:
			val=limits[i][1]
		elif val<limits[i][0]:
			val=limits[i][0]
		output[i]=val

	return output

GPIO.setmode(GPIO.BCM)
GPIO.setup(17, GPIO.OUT)
GPIO.output(17,0)

try:
	fn = sys.argv[1]
except:
	fn = 0

thrs=85

#sets how much to blur
filt=45
exitNow=0
pause=0

for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
	try:
		imgInit = frame.array
		cv2.imshow("Frame", imgInit)
				
		#imgBGR = cv2.resize(imgInit,(208, 208),cv2.INTER_AREA)
		img=cv2.cvtColor(imgInit, cv2.COLOR_BGR2HSV)
		
		while True:	
			if exitNow==1:
				break

			hue = 70
			sat = 160
			val = 180
			GPIO.output(17,0)
			
			lower=[hue,sat,val]
			lower=np.array(lower, dtype="uint8")
			lower2=[[[hue,sat,val]]]
			lower2=np.array(lower2, dtype="uint8")
			chosenColor = cv2.cvtColor(lower2, cv2.COLOR_HSV2BGR)
		
			upperBound=limit(lower+thrs/2,[[0,179],[0,255],[0,255]])
			lowerBound=limit(lower-thrs/2,[[0,179],[0,255],[0,255]])
			mask=np.uint8(cv2.inRange(img,lowerBound,upperBound))


			vis = np.uint8(img.copy())
			vis[mask==0]=(0,0,0)
			
			gray2 = img[:,:,2] #only want black and white image
			gray = vis[:,:,2]

			blurred = cv2.GaussianBlur(gray, (filt, filt), 0)

			thresholdValue = 30
			thresh = cv2.threshold(blurred, thresholdValue, 255, cv2.THRESH_BINARY)[1]

			testArray=[(lower-thrs/2).tolist(),(lower+thrs/2).tolist(),lowerBound.tolist(),upperBound.tolist(),thresholdValue]


			cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[1]
		
			areas=int(len(cnts))

			splotch = np.zeros((1,areas),dtype=np.uint8)
			
			# loop over the contours
			try:	
				for i,c in enumerate(cnts,0):
				
					M = cv2.moments(c)
					splotch[0][i] = int(M["m00"])
				try:
					max1=np.argmax(splotch)
				except:
					max1=-1
				
				original=vis.copy()
				print(max1)

				if max1>-1:
					M = cv2.moments(cnts[max1])
					print("outputting hi")
					GPIO.output(17,1)
					cX = int(M["m10"] / M["m00"])
					cY = int(M["m01"] / M["m00"])

					cv2.drawContours(vis, [cnts[max1]], -1, (0, 255, 0), 2)
					cv2.circle(vis, (cX, cY), 7, (255, 255, 255), -1)
					cv2.putText(vis, "Green Light", (cX - 20, cY - 20),
					cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
			except:
				pass
			
			cc=(int(chosenColor[0][0][0]),int(chosenColor[0][0][1]),int(chosenColor[0][0][2]))
			
			visBGR=cv2.cvtColor(vis, cv2.COLOR_HSV2BGR) 
			thresh = cv2.cvtColor(thresh, cv2.COLOR_GRAY2BGR)
			
			cv2.imshow('Frame',np.hstack([imgInit, visBGR])) #np.hstack([original, vis]))#np.hstack([thresh, gray2]))
			
			ch=cv2.waitKey(1)
			rawCapture.truncate(0)

			if ch == 27:
				exitNow=True
				break
			
			elif ch==112 and pause==0:
				
				pause=1
				print("paused")
		
			elif ch==112 and pause ==1:
				pause=0
				print("unPaused")

				break
			elif pause==1:
				pass
			else:
				break
	except KeyboardInterrupt:
		raise
	except cv2.error as e:

		print("Here it is \n",str(e), "\n")
		if similar(str(e), " /home/pi/opencv-3.3.0/modules/imgproc/src/imgwarp.cpp:3483: error: (-215) ssize.width > 0 && ssize.height > 0 in function resize")>.8:
			print("\n\n\n\n Your video appears to have ended\n\n\n")
		break
							
cv2.destroyAllWindows()
















		
