import RPi.GPIO as GPIO
from time import sleep

GPIO.setmode(GPIO.BCM)

GPIO.setup(21, GPIO.OUT)
GPIO.setup(22, GPIO.OUT)
GPIO.setup(23, GPIO.OUT)
GPIO.setup(24, GPIO.OUT)
GPIO.setup(25, GPIO.OUT)
GPIO.setup(26, GPIO.OUT)
GPIO.setup(27, GPIO.OUT)

GPIO.setup(12, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

gameWon = 0
b = 0
prevB=0 

while gameWon == 0:
        
        for i in range(7):
                if gameWon == 0:
                        i=i+21
                        GPIO.output(i,1)
                        for x in range(7):
                                x=x+21
                                if x!=i:
                                        GPIO.output(x,0)
                        b = GPIO.input(12)
                        if b == 1 and prevB == 1:
                                b = 0
                                prevB = 1
                        elif b == 0 and prevB == 1:
                                prevB = 0
                        elif b == 1 and prevB == 0:
                                prevB=1
                        print("b = ", b)
                        print("prevB = ", prevB)
                        print("i = ", i)

                        if b==1 and i==24:
                            print("Winner, Winner Chicken Dinner!")
                            for n in range(5):
                                    pwm = GPIO.PWM(24,1000)
                                    sleep(0.5)
                                    gameWon = 1
                                    break
                        sleep(0.3)
        
                else:
                        GPIO.cleanup()
                        break
                        


                        
                
                


        
        
