import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)

GPIO.setup(21, GPIO.OUT)
GPIO.setup(22, GPIO.OUT)
GPIO.setup(23, GPIO.OUT)
GPIO.setup(24, GPIO.OUT)
GPIO.setup(25, GPIO.OUT)
GPIO.setup(26, GPIO.OUT)
GPIO.setup(27, GPIO.OUT)

GPIO.setup(5, GPIO.IN, pull_up_down=GPIO.PUD_UP)
gameWon = 0

while gameWon == 0:
	for i in range(7):
		if gamewon == 0:
			i=i+21
			GPIO.output(i,GPIO.HIGH)
	
			for x in range(7):
				x=x+21
				if x!=i:
					GPIO.output(x,GPIO.LOW)
			if GPIO.input(5)==HIGH and i==24:
				for n in range(5):
					pwm = GPIO.PWM (24, 1)
					gameWon = 1
		else:
			break
			
			
		
		


	
	
